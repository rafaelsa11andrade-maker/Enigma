import React, { useState, useEffect, useRef } from 'react';
import { Button, Input, Card } from '@/components/ui';
import { motion } from 'framer-motion';

export default function EnigmaSite() {
  const DEFAULT_QUESTION = "Eu sou papel muito importante para vida e para certos processos e além disso sou uma parte de um código o que eu sou??";
  const CORRECT_ANSWER = "Aminoácidos";
  const SECRET_QUESTION = "Quantos aminoácidos são essenciais ?";
  const SECRET_ANSWER = "20";

  const [question, setQuestion] = useState(DEFAULT_QUESTION);
  const [input, setInput] = useState('');
  const [history, setHistory] = useState([]);
  const [secretUnlocked, setSecretUnlocked] = useState(false);
  const [finalMessage, setFinalMessage] = useState('');
  const [showImage, setShowImage] = useState(false);
  const viewRef = useRef(null);

  useEffect(() => {
    viewRef.current?.scrollTo({ top: viewRef.current.scrollHeight, behavior: 'smooth' });
  }, [history, finalMessage]);

  function handleSubmit(e) {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;

    if (question === DEFAULT_QUESTION) {
      if (trimmed === CORRECT_ANSWER) {
        setHistory([...history, { question, answer: trimmed, correct: true }]);
        setSecretUnlocked(true);
        setQuestion(SECRET_QUESTION);
      } else {
        setHistory([...history, { question, answer: trimmed, correct: false }]);
      }
    } else if (question === SECRET_QUESTION) {
      if (trimmed === SECRET_ANSWER) {
        setHistory([...history, { question, answer: trimmed, correct: true }]);
        setFinalMessage('✅ Parabéns! Vocês descobriram o dia que começa o Despertar da Floresta: o chamado da natureza... espero vocês lá Agentes🌲');
        setShowImage(true);
      } else {
        setHistory([...history, { question, answer: trimmed, correct: false }]);
      }
    }

    setInput('');
  }

  return (
    <div className="min-h-screen bg-green-950 text-white grid place-items-center p-4">
      <Card className="w-full max-w-3xl p-6 bg-green-900/80 border border-green-700 rounded-2xl shadow-lg">
        <div ref={viewRef} className="overflow-auto max-h-[60vh] font-mono text-sm mb-4">
          {history.map((item, index) => (
            <motion.div key={index} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>
              <span className={item.correct ? 'text-green-400' : 'text-red-400'}>&gt; {item.answer}</span> - {item.correct ? '✅' : '❌'}
            </motion.div>
          ))}
        </div>

        {!finalMessage && (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="font-semibold text-lg">
              {question}
            </motion.div>
            <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Digite sua resposta..." />
            <Button type="submit">Enviar</Button>
          </form>
        )}

        {finalMessage && (
          <div className="flex flex-col items-center gap-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="font-bold text-lg">
              {finalMessage}
            </motion.div>
            {showImage && (
              <motion.img
                src="https://upload.wikimedia.org/wikipedia/commons/8/89/Amino_Acids.svg"
                alt="Aminoácidos"
                className="max-w-full rounded-lg"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
              />
            )}
          </div>
        )}
      </Card>
    </div>
  );
}
