import React from 'react';

export function Button({ children, ...props }) {
    return <button {...props} className='bg-green-700 hover:bg-green-600 rounded p-2'>{children}</button>;
}

export function Input(props) {
    return <input {...props} className='p-2 rounded border border-green-600 bg-green-800 text-white' />;
}

export function Card({ children, ...props }) {
    return <div {...props} className='p-4 rounded-lg bg-green-900'>{children}</div>;
}
